from flask import Flask, render_template, request, redirect
from database import *

app = Flask(__name__)

#TODO: tambahkan session (clara)
#TODO: tambahakn login required untuk beberapa pages (clara)
#TODO: ttambahkan cursor

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=["POST", "GET"])
def login():
    if request.method == "GET":
        return render_template('login.html')
    usn = request.form.get("username")
    pwd = request.form.get("password")
    #TODO: checking if the usn and pwd correct atau nggak
    return redirect("/")

@app.route('/signup', methods=["POST", "GET"])
def signup():
    if request.method == "GET":
        return render_template('signup.html')
    usn = request.form.get("username")
    pwd = request.form.get("password")
    con_pwd = request.form.get("con_password")
    #TODO: checking apakah usn sudah ada, apakah passwd dan confirm passwordnya sama atau tidak
    # insert_user(cursor, usn, pwd)
    return redirect("/")
