import mysql.connector
from mysql.connector import Error
import bcrypt
import csv

"""Nama fungsi dan parameternya:
1. readfile(filename)
2. create_database(cursor)
3. create_tbcatalogue(cursor)
4. create_tbuser(cursor)
5. create_tbrenting(cursor)
6. insert_catalogue(cursor) -> semua image formatnya .jpeg
7. insert_user(cursor, username, password)
8. verify_user(cursor, username, password)
9. update_catalogue(cursor, catalogue_id, column, new_value) -> ini cuma bisa edit 1 kolom, perlu bikin bisa edit banyak kolom ga?
10. delete_catalogue(cursor, catalogue_id)
- select_all(cursor, table)
- drop_database(cursor)
"""

def readfile(filename):
    lines = []
    with open(filename, "r", encoding="utf-8") as file:
        for line in file:
            lines.append(line.replace("\n", "").split(","))
    return lines[1:]


def create_database(cursor):
    try:
        cursor.execute("create database if not exists carDB")
        print("database created")
    except Error as e:
        print(e)
    cursor.execute("use carDB")


def create_tbcatalogue(cursor):
    try:
        cursor.execute("""create table if not exists Catalogue (
                       id varchar(15) primary key,
                       brand varchar(31),
                       model varchar(31),
                       color varchar(31),
                       plate varchar(31),
                       year year,
                       seats int,
                       price int,
                       availability enum("Yes", "No"),
                       image mediumblob
                       )""")
        print("table Catalogue created")
    except Error as e:
        print(e)


def create_tbuser(cursor):
    try:
        cursor.execute("""create table if not exists User (
                       id int auto_increment primary key,
                       username varchar(31),
                       password varchar(31)
                       )""")
        print("table User created")
    except Error as e:
        print(e)


def create_tbrenting(cursor):
    try:
        cursor.execute("""create table if not exists Renting (
                       user_id int,
                       catalogue_id varchar(15),
                       name varchar(255),
                       contact_number int,
                       address varchar(255),
                       start_date date,
                       period int,
                       foreign key (user_id) references User(id),
                       foreign key (catalogue_id) references Catalogue(id)
                       )""")
        print("table Renting created")
    except Error as e:
        print(e)


def insert_catalogue(cursor):
    lines = readfile("catalogue.csv")
    new_lines = []

    for line in lines:
        id, brand, model, color, plate, year, seats, price, availability = line
        binary_data = None
        img_path = f"catalogue_img/{line[0]}.jpeg"
        with open(img_path, "rb") as file:
            binary_data = file.read()

        new_lines.append([id, brand, model, color, plate, year, seats, price, availability, binary_data])
    
    string = """
    INSERT INTO Catalogue (id, brand, model, color, plate, year, seats, price, availability, image)
    VALUES ({})""".format(", ".join(["%s"] * 10))

    try:
        cursor.executemany(string, new_lines)
        print("data inserted into catalogue")
    except Error as e:
        print("Error:", e)


def insert_user(cursor, username, password):
    hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    query = "insert into User (username, password) values (%s, %s)"
    
    try:
        cursor.execute(query, (username, hashed_password))
        print("User added successfully!")
    except Error as e:
        print("Error:", e)


def verify_user(cursor, username, password):
    query = "SELECT password FROM User WHERE username = %s"
    cursor.execute(query, (username,))
    result = cursor.fetchone()

    if result and bcrypt.checkpw(password.encode(), result[0].encode()):
        print("Login successful!")
        return True
    else:
        print("Invalid username or password")
        return False


def update_column(cursor, catalogue_id, column, new_value):
    try:
        query = f"update Catalogue set {column} where id = %s"
        cursor.execute(query, (new_value, catalogue_id))
        print("table Catalogue updated")
    except Error as e:
        print("Error:", e)


def update_columns(cursor, catalogue_id, columns, new_values):
    string = ", ".join([f"{col} = %s" for col in columns])
    try:
        query = f"update Catalogue set {string} = %s where id = %s"
        print("table Catalogue updated")
    except Error as e:
        print("Error:", e)



def delete_catalogue(cursor, catalogue_id):
    try:
        cursor.execute(f"delete from catalogue where id = {catalogue_id}")
        print("catalogue deleted")
    except Error as e:
        print("Error:", e)


def select_all(cursor, table):
    print("hai")
    cursor.execute(f"select * from {table}")
    data = cursor.fetchall()
    print(data)
    return data 

"""- edit secara umum
- edit availability
- delete"""

# def 

def drop_database(cursor):
    cursor.execute(f"drop database carDB")